package ly.najah.maktabi

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class Item(val service: String, val qty: Double, val price: Double) {
    val total get() = qty * price
}
data class Inv(val id: Long, val customer: String, val created: Long, val total: Double)

class Db(c: Context) : SQLiteOpenHelper(c, "maktabi.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT, created INTEGER, total REAL)")
        db.execSQL("CREATE TABLE items(id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_id INTEGER, service TEXT, qty REAL, price REAL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}

    fun save(customer: String, items: List<Item>): Inv {
        val db = writableDatabase
        val now = System.currentTimeMillis()
        val total = items.sumOf { it.total }
        db.beginTransaction()
        try {
            val id = db.insert("invoices", null, ContentValues().apply {
                put("customer", customer); put("created", now); put("total", total)
            })
            for (i in items) db.insert("items", null, ContentValues().apply {
                put("invoice_id", id); put("service", i.service); put("qty", i.qty); put("price", i.price)
            })
            db.setTransactionSuccessful()
            return Inv(id, customer, now, total)
        } finally { db.endTransaction() }
    }

    fun recent(limit: Int = 20): List<Inv> {
        val out = mutableListOf<Inv>()
        readableDatabase.rawQuery("SELECT id,customer,created,total FROM invoices ORDER BY id DESC LIMIT $limit", null).use {
            while (it.moveToNext()) out += Inv(it.getLong(0), it.getString(1) ?: "", it.getLong(2), it.getDouble(3))
        }
        return out
    }

    fun items(invoiceId: Long): List<Item> {
        val out = mutableListOf<Item>()
        readableDatabase.rawQuery("SELECT service,qty,price FROM items WHERE invoice_id=? ORDER BY id", arrayOf(invoiceId.toString())).use {
            while (it.moveToNext()) out += Item(it.getString(0), it.getDouble(1), it.getDouble(2))
        }
        return out
    }
}
