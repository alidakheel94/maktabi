package ly.najah.maktabi

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.print.PrintAttributes
import android.print.PrintManager
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.*
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private val blue = Color.parseColor("#1769aa")
    private val shop = "مكتب النجاح للطباعة والتصوير"
    private val services = listOf("تصوير أبيض وأسود", "تصوير ملون", "طباعة أبيض وأسود",
        "طباعة ملونة", "تغليف وتجليد", "مسح ضوئي (سكانر)", "خدمات أخرى")
    private val fmt = DecimalFormat("#,##0.###", DecimalFormatSymbols(Locale.US))
    private val items = mutableListOf<Item>()
    private lateinit var db: Db
    private lateinit var spinner: Spinner
    private lateinit var other: EditText
    private lateinit var qty: EditText
    private lateinit var price: EditText
    private lateinit var customer: EditText
    private lateinit var itemsBox: LinearLayout
    private lateinit var totalTv: TextView
    private lateinit var recentBox: LinearLayout
    private var printView: WebView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun num(s: String): Double? {
        val sb = StringBuilder()
        for (ch in s.trim()) sb.append(when (ch) {
            in '٠'..'٩' -> '0' + (ch - '٠'); in '۰'..'۹' -> '0' + (ch - '۰')
            '٫', '،', ',' -> '.'; else -> ch })
        return sb.toString().toDoubleOrNull()
    }

    private fun edit(hint: String, numeric: Boolean) = EditText(this).apply {
        this.hint = hint; textSize = 16f; gravity = Gravity.START
        if (numeric) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_NUMBER_FLAG_DECIMAL
    }
    private fun btn(t: String, onClick: () -> Unit) = Button(this).apply {
        text = t; setTextColor(Color.WHITE); setBackgroundColor(blue); setOnClickListener { onClick() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        db = Db(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(16), dp(16), dp(32))
        }
        col.addView(TextView(this).apply {
            text = "مكتبي\n$shop"; setTextColor(Color.WHITE); setBackgroundColor(blue)
            textSize = 20f; gravity = Gravity.CENTER; setPadding(dp(12), dp(16), dp(12), dp(16))
        })
        spinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, services)
            onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    other.visibility = if (pos == services.lastIndex) View.VISIBLE else View.GONE
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
        other = edit("اسم الخدمة", false).apply { visibility = View.GONE }
        qty = edit("الكمية", true); price = edit("سعر الوحدة (د.ل)", true)
        customer = edit("اسم العميل (اختياري)", false)
        itemsBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        totalTv = TextView(this).apply { textSize = 20f; setTextColor(blue); setPadding(0, dp(8), 0, dp(8)) }
        recentBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        listOf(spinner, other, qty, price).forEach { col.addView(it) }
        col.addView(btn("＋ إضافة للفاتورة") { addItem() })
        col.addView(itemsBox); col.addView(totalTv); col.addView(customer)
        col.addView(btn("حفظ وطباعة الفاتورة") { saveAndPrint() })
        col.addView(TextView(this).apply {
            text = "آخر الفواتير (اضغط للطباعة مجدداً)"; textSize = 16f; setPadding(0, dp(24), 0, dp(8))
        })
        col.addView(recentBox)

        setContentView(ScrollView(this).apply { addView(col); layoutDirection = View.LAYOUT_DIRECTION_RTL })
        refresh()
    }

    private fun addItem() {
        val q = num(qty.text.toString()); val p = num(price.text.toString())
        if (q == null || p == null || q <= 0 || p < 0) { toast("أدخل الكمية والسعر بشكل صحيح"); return }
        var name = services[spinner.selectedItemPosition]
        if (other.visibility == View.VISIBLE && other.text.isNotBlank()) name = other.text.toString().trim()
        items += Item(name, q, p)
        qty.text.clear(); price.text.clear(); other.text.clear()
        refresh()
    }

    private fun refresh() {
        itemsBox.removeAllViews()
        items.forEachIndexed { i, it ->
            itemsBox.addView(TextView(this).apply {
                text = "${it.service}: ${fmt.format(it.qty)} × ${fmt.format(it.price)} = ${fmt.format(it.total)}  ✕"
                textSize = 16f; setPadding(0, dp(8), 0, dp(8))
                setOnClickListener { items.removeAt(i); refresh() }
            })
        }
        totalTv.text = "الإجمالي: ${fmt.format(items.sumOf { it.total })} د.ل"
        recentBox.removeAllViews()
        val df = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US)
        for (inv in db.recent()) recentBox.addView(TextView(this).apply {
            text = "فاتورة #${inv.id} — ${df.format(Date(inv.created))} — ${fmt.format(inv.total)} د.ل"
            textSize = 15f; setPadding(0, dp(10), 0, dp(10))
            setOnClickListener { printInvoice(inv, db.items(inv.id)) }
        })
    }

    private fun saveAndPrint() {
        if (items.isEmpty()) { toast("أضف خدمة واحدة على الأقل"); return }
        val inv = db.save(customer.text.toString().trim(), items.toList())
        val saved = items.toList()
        items.clear(); customer.text.clear(); refresh()
        printInvoice(inv, saved)
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun html(inv: Inv, list: List<Item>): String {
        val rows = list.joinToString("") {
            "<tr><td>${esc(it.service)}</td><td>${fmt.format(it.qty)}</td><td>${fmt.format(it.price)}</td><td>${fmt.format(it.total)}</td></tr>"
        }
        val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date(inv.created))
        val cust = if (inv.customer.isBlank()) "" else "<p>العميل: ${esc(inv.customer)}</p>"
        return """<html dir="rtl" lang="ar"><head><meta charset="utf-8"><style>
            body{font-family:Tahoma,Arial,sans-serif;padding:16px;direction:rtl}
            h1{color:#1769aa;text-align:center;margin:0}
            table{width:100%;border-collapse:collapse;margin-top:12px}
            th{background:#1769aa;color:#fff}
            th,td{border:1px solid #999;padding:6px;text-align:center}
            .t{font-size:18px;font-weight:bold;margin-top:12px}
            </style></head><body>
            <h1>${esc(shop)}</h1><p style="text-align:center">فاتورة رقم ${inv.id}</p>
            <p>التاريخ: $date</p>$cust
            <table><tr><th>الخدمة</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr>$rows</table>
            <p class="t">الإجمالي النهائي: ${fmt.format(inv.total)} دينار ليبي</p>
            </body></html>"""
    }

    private fun printInvoice(inv: Inv, list: List<Item>) {
        val wv = WebView(this)
        printView = wv
        var done = false
        wv.webViewClient = object : WebViewClient() {
            override fun onPageFinished(v: WebView, url: String?) {
                if (done) return
                done = true
                val name = "فاتورة_${inv.id}"
                val pm = getSystemService(PRINT_SERVICE) as PrintManager
                pm.print(name, v.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
            }
        }
        wv.loadDataWithBaseURL(null, html(inv, list), "text/html", "UTF-8", null)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
